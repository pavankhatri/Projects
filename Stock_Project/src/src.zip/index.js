import React from 'react';
import ReactDOM from 'react-dom';
import Stock from './Component/Stock';

ReactDOM.render(
  <div>
    <Stock/>
  </div>,
  document.getElementById('root')
)

